echo  Entrer le mot de passe du compte
echo 
sudo cp 10-local.rules /etc/udev/rules.d/10-local.rules
echo on install les dev usb
sudo apt install libusb-dev
